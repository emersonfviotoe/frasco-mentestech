// app.js - simula autenticação e mostra cursos
const demoUser = { user: "demo", pass: "demo123", name: "Usuário Demo" };

function $(sel){return document.querySelector(sel)}

document.addEventListener('DOMContentLoaded', ()=> {
  const loginForm = $('#loginForm');
  if(loginForm){
    loginForm.addEventListener('submit', e=>{
      e.preventDefault();
      const u = $('#user').value.trim();
      const p = $('#pass').value;
      const msg = $('#loginMsg');
      if(u === demoUser.user && p === demoUser.pass){
        localStorage.setItem('mentestech_user', JSON.stringify({user:u, name: demoUser.name}));
        msg.textContent = 'Login efetuado com sucesso! Redirecionando...';
        setTimeout(()=> location.href = 'dashboard.html', 700);
      } else {
        msg.textContent = 'Credenciais inválidas (use demo / demo123)';
      }
    })
  }

  // Logout
  const logoutBtn = $('#logoutBtn');
  if(logoutBtn){
    logoutBtn.addEventListener('click', ()=>{
      localStorage.removeItem('mentestech_user');
      location.href = 'index.html';
    });
  }

  // Protege dashboard
  if(location.pathname.endsWith('dashboard.html')){
    const st = localStorage.getItem('mentestech_user');
    const area = $('#studentArea');
    if(!st){
      area.innerHTML = '<p>Você não está autenticado. <a href="index.html">Faça login</a></p>';
    } else {
      const user = JSON.parse(st);
      area.innerHTML = `<p>Bem-vindo, <strong>${user.name}</strong>! Aqui está a sua lista de cursos inscritos e progresso (simulado).</p>
      <ul>
        <li>Python — Progresso: 20%</li>
        <li>Desenvolvimento Web — Progresso: 0%</li>
        <li>Inteligência Artificial — Progresso: 0%</li>
      </ul>`;
    }
  }

  // Cursos list
  const courses = [
    {id:'python', title:'Programação Python', desc:'Do zero ao avançado. Prática e projetos.', img:'images/curso1.jpg'},
    {id:'web', title:'Desenvolvimento Web', desc:'HTML, CSS, JavaScript e frameworks.', img:'images/curso2.jpg'},
    {id:'ia', title:'Inteligência Artificial', desc:'Machine Learning aplicado a projetos.', img:'images/curso3.jpg'}
  ];
  const courseList = $('#courseList');
  if(courseList){
    courseList.innerHTML = courses.map(c=>`
      <div class="course">
        <img src="${c.img}" alt="${c.title}">
        <h3>${c.title}</h3>
        <p>${c.desc}</p>
        <p><a class="btn" href="cursos/${c.id}.html">Ver curso</a></p>
      </div>
    `).join('');
  }
});
